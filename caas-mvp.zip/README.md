# Chain as a Service (CaaS)

Final MVP repository for Chain-as-a-Service.

## Structure
- contracts: Solidity smart contracts
- backend: Node.js + TypeScript services
- frontend: Minimal intent UI

## License
MIT
